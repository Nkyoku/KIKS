// HEX to VHD

#include <stdio.h>
#include <stdlib.h>
#include <locale.h>

#include "hexload.h"



static const int MAX_LENGTH = 10 * 1024 * 1024;
static const int WRAP = 64;



// ���C��
int wmain(int num_of_arg, wchar_t *arg[]){
	_wsetlocale(LC_ALL, L"");

	if (num_of_arg != 5){
		_putws(L"hex2vhd [INPUT.HEX] [OFFSET ADDRESS] [LENGTH] [OUTPUT.VHD]");
		return 0;
	}

	wchar_t *input_path = arg[1];
	wchar_t *output_path = arg[4];
	unsigned int offset = _wtoi(arg[2]);
	unsigned int length = _wtoi(arg[3]);

	if (MAX_LENGTH <= length){
		_putws(L"The [LENGTH] field is too large.");
		return 0;
	}

	bool result;
	char *buf = new char[length];
	result = LoadIntelHEX(input_path, buf, nullptr, length, offset);

	if (result == false){
		_putws(L"Processing failed at loading [INPUT.HEX].");
	}else{
		FILE *fp;
		if (_wfopen_s(&fp, output_path, L"w") != 0){
			_putws(L"Processing failed at opening [OUTPUT.VHD].");
		}else{
			int slength = length;
			for(int cnt = 0; cnt < slength; cnt++){
				fwprintf(fp, L"X\"%02X\"", (unsigned char)buf[cnt]);
				if (cnt != (slength - 1)){
					fwprintf(fp, L",");
				}
				if ((cnt % WRAP) == (WRAP - 1)){
					fwprintf(fp, L"\n");
				}
			}
			fclose(fp);
		}
	}
	delete [] buf;

	return 0;
}
